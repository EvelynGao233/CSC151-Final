
// This goes in the second web page:
// Retrieve the sessionStorage variable
var originalC = sessionStorage.getItem('originalColor');


document.body.style.backgroundColor = originalC